from TestBlog import app as application
import sys

sys.path.insert(0,’/var/www/TestBlog’)
